<section id="contact">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2 text-center">
                    <h2 class="section-heading">Contact</h2>
                    <hr class="primary">
                    <p>Sign Up To Learn More</p>
                    <form action="thanks.php">
                        <div>
                            <h1></h1>
                            <input placeholder="Please enter your email"/>
                            <h1></h1>
                        </div>
                        <button type="submit" class="btn btn-primary btn-xl page-scroll" style="margin-bottom:10px;">SUBMIT</button>
                </form>
            
                </div>
                <div class="col-lg-8 col-lg-offset-2 text-center">
                    <i class="fa fa-phone fa-3x sr-contact"></i>
                    <p>513-125-6787</p>
                </div>
                
                <div class="col-lg-8 col-lg-offset-2 text-center">
                    <i class="fa fa-envelope-o fa-3x sr-contact"></i>
                    <p><a href="feedback@bachelordegreepro.com">feedback@bachelordegreepro.com</a></p>
                </div>
                <div class="col-lg-8 col-lg-offset-2 text-center">
                    <a href="privacy.php"><i class="fa fa-user-secret fa-3x sr-contact"></i>
                    <p>Privacy Policy</a></p>
                </div>
            </div>
        </div>
    </section>