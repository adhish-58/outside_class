<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>BachelorDegreePros.com</title>

    <!-- Bootstrap Core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>

    <!-- Plugin CSS -->
    <link href="vendor/magnific-popup/magnific-popup.css" rel="stylesheet">

    <!-- Theme CSS -->
    <link href="css/creative.min.css" rel="stylesheet">
    


    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body id="page-top">

    <nav id="mainNav" class="navbar navbar-default navbar-fixed-top">
        <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span> Menu <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand page-scroll" href="#page-top"><img src="img/logo.png" /></a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a class="page-scroll" href="#">Home</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#about">About</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#types">Types</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="#contact">Contact</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>
    
    <header>
            <div class="header-content">
                <div class="header-content-inner">
                    <h1 id="homeHeading">Your Bachelor Degree Starts Here</h1>
                    <hr>
                    <a href="#about" class="btn btn-primary btn-xl page-scroll">Find Out More</a>
                </div>
            </div>
       
    </header>
    

    <section class="bg-primary" id="about">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-lg-offset-2 text-center">
                    <h2 class="section-heading">About</h2>
                    <hr class="light">
                    <p class="text-faded">A bachelor’s degree is a post-secondary undergraduate program that takes between three to four years to complete. A three-year program is a variation of the traditional four-year degree where students had to take 120 credits or 40 courses in the full-time study. In colleges that subscribe to the quarter system, students have to complete 180 credits to get an accredited bachelor’s degree. All institutions offering the degree programs must receive accreditation from the regulatory bodies. 
In most instances, the bulk of the baccalaureate degrees consist of general education courses such as English, psychology, history, mathematics and critical thinking. The major area of study carries 30-36 credits. Today, the graduate degree remains an essential requirement for entering into professional careers hence the reason you cannot enroll in occupational medicine, engineering and law schools without the qualifications. It holds the key to promising career opportunities. 
An associate degree is a two-year course that prepares learners for entry into the job market. They are tailored to impart necessary skills and competencies required for a particular career. Most conventional colleges offer 2+2 programs where students earn an associate degree in the first two years of the four-year program. In such instances, they can proceed with the post associate in a larger institution, which makes it easy and affordable way to get a degree. 
</p>
                    <a href="#types" class="page-scroll btn btn-default btn-xl sr-button">Learn More about Types</a>
                </div>
            </div>
        </div>
    </section>

    <section id="types">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">Types</h2>
                    <hr class="primary">
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-md-3 text-center">
                    <div class="service-box">
                        <i class="fa fa-4x fa-paint-brush text-primary sr-icons"></i>
                        <h3>Bachelor of Arts</h3>
                        <p class="text-muted">Other than being the most common in most institutions, Bachelor of Arts requires fewer concentration courses as it is more inclined toward liberal arts. When it comes to customizing learning to suit specific career goals, students have little opportunity to tailor the program. The course takes three to four years based on the mode of operations. In some traditional universities such as Oxford and Cambridge, the course is awarded to students pursuing all subjects including the scientific degrees. One can choose to major in theater, English, Fine arts, modern languages, music, and communications among other disciplines. </p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 text-center">
                    <div class="service-box">
                        <i class="fa fa-4x fa-flask text-primary sr-icons"></i>
                        <h3>Bachelor of Science</h3>
                        <p class="text-muted">Available in almost all the higher learning institutions, Bachelors of Science degree leans towards particular concentration as opposed to exploration. The learners focus on a particular field and tend to be more career focused that those pursuing general programs. It takes 3-4 years to complete a B.Sc. program, with majors ranging from engineering, informatics, mathematics, agriculture, health, economics, and business among others. </p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 text-center">
                    <div class="service-box">
                        <i class="fa fa-4x fa-calculator text-primary sr-icons"></i>
                        <h3>Accelerated degree programs</h3>
                        <p class="text-muted">In modern learning, the type of the degree program and the college that offers the course determines the time it takes earn accreditation. The mode of learning ranges from full time to part time, online, evening and weekend modules. Unlike the conventional four-year degrees, accelerated online bachelor degree programs take two years of part-time programs taking longer. Students with associate degrees and those with post-secondary courses qualify for the accelerated degree programs. Similarly, those with transferable higher education credits, workforce training and expert experience may enroll for the courses. </p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 text-center">
                    <div class="service-box">
                        <i class="fa fa-4x fa-television  text-primary sr-icons"></i>
                        <h3>Online bachelor’s degree</h3>
                        <p class="text-muted">If you have little time to take full-time programs, online degrees programs, help achieve the goal as you pursue others. The programs are flexible hence allows students take the courses at their pace as well as benefit from geographical limitations. The period depends on the amount of time you dedicate to studies but often lasts between three and five years. </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="no-padding" id="portfolio">

        <div class="container-fluid">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">Top Ranked Universities</h2>
                    <hr class="primary">
                </div>
            </div>
        </div>
            <div class="row no-gutter popup-gallery">
                <div class="col-lg-4 col-sm-6">
                    <a href="img/harvard.jpg" class="portfolio-box">
                        <img src="img/harvard.jpg" class="img-responsive" alt="">
                        <div class="portfolio-box-caption">
                            <div class="portfolio-box-caption-content">
                                <div class="project-category text-faded">
                                    Harvard University
                                </div>
                                <div class="project-name">
                                    Cambridge, MA
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-4 col-sm-6">
                    <a href="img/princeton.jpg" class="portfolio-box">
                        <img src="img/princeton.jpg" class="img-responsive" alt="">
                        <div class="portfolio-box-caption">
                            <div class="portfolio-box-caption-content">
                                <div class="project-category text-faded">
                                    Princeton University
                                </div>
                                <div class="project-name">
                                    Princeton, NJ
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-4 col-sm-6">
                    <a href="img/chicago.jpg" class="portfolio-box">
                        <img src="img/chicago.jpg" class="img-responsive" alt="">
                        <div class="portfolio-box-caption">
                            <div class="portfolio-box-caption-content">
                                <div class="project-category text-faded">
                                    University of Chicago
                                </div>
                                <div class="project-name">
                                    Chicago, IL
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-4 col-sm-6">
                    <a href="img/yale.jpg" class="portfolio-box">
                        <img src="img/yale.jpg" class="img-responsive" alt="">
                        <div class="portfolio-box-caption">
                            <div class="portfolio-box-caption-content">
                                <div class="project-category text-faded">
                                    Yale University
                                </div>
                                <div class="project-name">
                                    New Haven, CT
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-4 col-sm-6">
                    <a href="img/columbia.jpg" class="portfolio-box">
                        <img src="img/columbia.jpg" class="img-responsive" alt="">
                        <div class="portfolio-box-caption">
                            <div class="portfolio-box-caption-content">
                                <div class="project-category text-faded">
                                    Columbia University
                                </div>
                                <div class="project-name">
                                    New York, NY
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-4 col-sm-6">
                    <a href="img/standford.jpg" class="portfolio-box">
                        <img src="img/standford.jpg" class="img-responsive" alt="">
                        <div class="portfolio-box-caption">
                            <div class="portfolio-box-caption-content">
                                <div class="project-category text-faded">
                                    Standford University
                                </div>
                                <div class="project-name">
                                    Standford, CA
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </section>

    <aside class="bg-dark">
        <div class="container text-center">
            <div class="call-to-action">
                <h2>Choosing the right program</h2>
                <div class="col-lg-12 col-md-12 text-center">
                        <p class="text-muted">There are as many degree programs as there are colleges across the globe. Before you choose a degree program and a college for that matter, several factors ought to come into play. The program ought to fulfill the requirements of the intended career, and the college of choice should have necessary accreditation from the relevant professional bodies. Consider the available mode of learning and see to it that it suits your schedule as well as the length of the whole program.
When it comes to choosing the learning institution, you cannot wish away the cost factor for a similar course in different universities. You might be thrilled to enroll in colleges that offer financial aid to supplement the tuition fees. In case you have prospects to continue with the discipline, the ability to transfer the degree comes into question.  </p>
                    
                </div>
            </div>
            <div class="call-to-action">
                <h2>Why you need a bachelor’s degree?</h2>
                <div class="col-lg-12 col-md-12 text-center">
                        <p class="text-muted">Regardless of the field of study, a bachelor’s degree unlocks the potential to enter the lucrative job market not as a technician but middle-level manager. Other than the work-related skills, the programs impart leadership and entrepreneurial competencies required propel the learners into higher management positions. Amid high unemployment rates across the globe, people with a bachelor’s degree stand a better chance than those with diplomas and high school certificates.  While there are several positions for people with high school diplomas and associate degrees, they are limited to the entry levels. They need to have a degree to qualify for senior positions. 
According to a Georgetown survey, college graduates make 84% more than their high school counterparts do. According to the national center for educational statistics, a whopping 72% of young adults with bachelor’s degree worked full time as of 2013, where college graduates made more than twice of what the highs school graduates earned. College graduates earn at least $13000 more than those with associate degrees, which might make the difference in the quality of life. 
The trend for higher pay is on the rise as one progresses with higher learning. In the public and private sector, a master’s degree attracts a higher pay than a bachelor’s degree, with the doctoral exceeding the master's post-graduates pay. Nonetheless, a bachelor’s degree is the best way to get the best back at a younger age, as graduate programs require more time and money to realize the returns. B.Sc. jobs such as medicine and engineering pays higher than B.A jobs such as arts and education. 
</p>
                    
                </div>
            </div>
        </div>
    </aside>
<?php include("footer.php") ?>

    <!-- jQuery -->
    <script src="vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
    <script src="vendor/scrollreveal/scrollreveal.min.js"></script>
    <script src="vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

    <!-- Theme JavaScript -->
    <script src="js/creative.min.js"></script>
</body>

</html>

