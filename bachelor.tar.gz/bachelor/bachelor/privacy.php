<?php include("header.php") ?>
	<header>
            <div class="header-content">
                <div class="header-content-inner">
                    <h1 id="homeHeading">Privacy Policy</h1>
                    <hr>
                </div>
            </div>
    </header>
    <section>
    <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="section-heading">Privacy Policy</h2>
                    <hr class="long">
                    <p>What is this Privacy Policy for? This security approach is for this site [prominecraftservers.com] and served by [prominecraftservers.com] and administers the protection of its clients who use it. 

The approach sets out the distinctive territories where client security is concerned and plots the commitments and necessities of the clients, the site and site proprietors. Besides the way this site procedures, stores and ensures client information and data will likewise be nitty gritty inside this arrangement.</p>
                </div>
                <div class="col-lg-12">
                    <h2 class="section-heading">The Website </h2>
                    <hr class="long">
                    <p>This site and its proprietors take a proactive way to deal with client security and guarantee the fundamental strides are taken to ensure the protection of its clients all through their meeting background. This site agrees to all UK national laws and prerequisites for client protection. </p>
                </div>
                <div class="col-lg-12">
                    <h2 class="section-heading">Client of Cookies </h2>
                    <hr class="long">
                    <p>This site utilizes treats to better the clients experience while going by the site. Where pertinent this site utilizes a treat control framework permitting the client on their first visit to the site to permit or prohibit the utilization of treats on their PC/gadget. This agrees to late enactment necessities for sites to acquire unequivocal assent from clients before deserting or perusing records, for example, treats on a client's PC/gadget. 

Treats are little documents spared to the client's PCs hard drive that track, spare and store data about the client's collaborations and utilization of the site. This permits the site, through its server to give the clients a customized experience inside this site. Clients are prompted that on the off chance that they wish to deny the utilization and sparing of treats from this site on to their PCs hard drive they ought to step inside their web programs security settings to piece all treats from this site and its outside serving merchants. 

This site utilizes following programming to screen its guests to better see how they utilize it. This product is given by Google Analytics which utilizes treats to track guest utilization. The product will spare a treat to your PCs hard drive so as to track and screen your engagement and use of the site, yet won't store, spare or gather individual data. You can read Google's security strategy here for additional data [ http://www.google.com/privacy.html ]. Different treats might be put away to your PCs hard drive by outside sellers when this site utilizes referral programs, supported connections or adverts. Such treats are utilized for transformation and referral following and ordinarily terminate following 30 days, however some may take longer. No individual data is put away, spared or gathered. </p>
                </div>
                <div class="col-lg-12">
                    <h2 class="section-heading">Contact and Communication </h2>
                    <hr class="long">
                    <p>Clients reaching this site and/or its proprietors do as such at their own particular carefulness and give any such individual points of interest asked for at their own particular danger. Your own data is kept private and put away safely until a period it is no more required or has no utilization, as definite in the Data Protection Act 1998. Each exertion has been made to guarantee a protected and secure structure to email accommodation prepare however exhort clients utilizing such shape to email forms that they do as such at their own particular danger. This site and its proprietors utilize any data submitted to give you additional data about the items/administrations they offer or to help you in noting any inquiries or questions you may have submitted. This incorporates utilizing your points of interest to subscribe you to any email pamphlet program the site works yet just on the off chance that this was clarified to you and your express consent was conceded while presenting any structure to email process. Then again whereby you the purchaser have beforehand obtained from or enquired about acquiring from the organization an item or administration that the email bulletin identifies with. This is in no way, shape or form a whole rundown of your client rights as to getting email promoting material. Your subtle elements are not went on to any outsiders.</p>
                </div>
                <div class="col-lg-12">
                    <h2 class="section-heading">Email Newsletter </h2>
                    <hr class="long">
                    <p>This site works an email pamphlet program, used to educate supporters about items and administrations supplied by this site. Clients can subscribe through an online mechanized procedure if they wish to do as such yet do as such at their own particular carefulness. A few memberships might be physically handled through earlier composed concurrence with the client. 

Memberships are brought in consistence with UK Spam Laws point by point in the Privacy and Electronic Communications Regulations 2003. Every single individual point of interest identifying with memberships are held safely and as per the Data Protection Act 1998. No individual points of interest are passed on to outsiders nor imparted to organizations/individuals outside of the organization that works this site. Under the Data Protection Act 1998 you may ask for a duplicate of individual data held about you by this present site's email bulletin program. A little expense will be payable. In the event that you might want a duplicate of the data hung on you please keep in touch with the work locale at the base of this arrangement. 

Email showcasing effort distributed by this site or its proprietors may contain following offices inside the real email. Supporter movement is followed and put away in a database for future investigation and assessment. Such followed movement may incorporate; the opening of messages, sending of messages, the clicking of connections inside the email content, times, dates and recurrence of action [this is by no far a thorough list]. This data is utilized to refine future email battles and supply the client with more significant substance based around their movement. 

In consistence with UK Spam Laws and the Privacy and Electronic Communications Regulations 2003 endorsers are given the chance to un-subscribe whenever through a computerized framework. This procedure is nitty gritty at the footer of every email battle. On the off chance that a mechanized un-membership framework is distracted clear directions on the best way to un-subscribe will by nitty gritty.</p>
                </div>
                <div class="col-lg-12">
                    <h2 class="section-heading">Outside Links </h2>
                    <hr class="long">
                    <p>In spite of the fact that this site just hopes to incorporate quality, sheltered and applicable outside connections, clients are educated receive an arrangement with respect to alert before clicking any outer web joins said all through this site. (Outer connections are interactive content/standard/picture connections to different sites, like; www.kingstrains.co.uk or Kings Trains Models.) 

The proprietors of this site can't ensure or confirm the substance of any remotely connected site in spite of their earnest attempts. Clients ought to consequently note they tap on outer connections at their own particular danger and this site and its proprietors can't be held at risk for any harms or suggestions brought on by going by any outside connections said.</p>
                </div>
                <div class="col-lg-12">
                    <h2 class="section-heading">Adverts and Sponsored Links </h2>
                    <hr class="long">
                    <p>This site may contain supported connections and adverts. These will ordinarily be served through our promoting accomplices, to whom may have point by point protection approaches relating specifically to the adverts they serve. 

Tapping on any such adverts will send you to the promoters site through a referral project which may utilize treats and will track the quantity of referrals sent from this site. This may incorporate the utilization of treats which may thusly be saved money on your PCs hard drive. Clients ought to accordingly note they tap on supported outside connections at their own particular danger and this site and its proprietors can't be held obligated for any harms or suggestions brought about by going by any outer connections specified. </p>
                </div>
                <div class="col-lg-12">
                    <h2 class="section-heading">Online networking Platforms </h2>
                    <hr class="long">
                    <p>Correspondence, engagement and moves made through outer online networking stages that this site and its proprietors partake on are custom to the terms and conditions and also the protection approaches held with every social networking stage separately. 

Clients are encouraged to utilize online networking stages shrewdly and convey/draw in upon them with due consideration and alert concerning their own protection and individual subtle elements. This site nor its proprietors will ever request individual or delicate data through online networking stages and urge clients wishing to examine touchy subtle elements to get in touch with them through essential correspondence stations, for example, by phone or email. 

This site may utilize social sharing catches which offer web content specifically from website pages to the online networking stage being referred to. Clients are prompted before utilizing such social sharing catches that they do as such at their own particular circumspection and note that the online networking stage may track and spare your solicitation to share a page individually through your online networking stage account.</p>
                </div>
                <div class="col-lg-12">
                    <h2 class="section-heading">Shortned Links in Social Media</h2>
                    <hr class="long">
                    <p>This site and its proprietors through their online networking stage records may share web connections to important site pages. As a matter of course some online networking stages abbreviate protracted urls [web addresses] (this is a case: http://bit.ly/zyVUBo). Clients are encouraged to take alert and decision making ability before clicking any abbreviated urls distributed on online networking stages by this site and its proprietors. Regardless of the best endeavors to guarantee just certified urls are distributed numerous online networking stages are inclined to spam and hacking and thusly this site and its proprietors can't be held at risk for any harms or suggestions brought about by going to any abbreviated connections.</p>
                </div>
            </div>
        </div>
    </section>

<?php include("footer.php") ?>



</html>

