<?php include("header.php") ?>
<body>
	<div class="container" style="margin-top:50px;">
	<div class="row">
         <div class="col-lg-8 col-lg-offset-2 text-center">
            <h1>THANK YOU!!!</h1>
		</div>
	</div>
	</div>

<?php include("footer.php") ?>	
</body>
</html>